<!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2022 Online Career Guidance. All rights reserved | Design by <a href="#">Key Coder</a></p>
			</div>
		  </div>
  <!-- / footer -->