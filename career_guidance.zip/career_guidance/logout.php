<?php
session_start();
include('connection.php');

session_unset();

?>
<script language="javascript">
document.location="index.php";
</script>
